﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Server.Models;
using Microsoft.EntityFrameworkCore;

namespace Server.Pages.Attendance
{
    public class CreateModel : PageModel
    {
        private readonly Server.Data.ApplicationDBContext _context;

        public CreateModel()
        {
           
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Model.EmployeeAttendance EmployeeAttendance { get; set; }
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {   
            DateTime dateTime = DateTime.Now;

            //1: CheckIn is older than 1 minute
            //2: CheckIn is in the future
            if (DateTime.Compare(EmployeeAttendance.CheckIn, dateTime.AddMinutes(-1)) < 0
                || DateTime.Compare(EmployeeAttendance.CheckIn, dateTime) > 0)
            {
                TempData["error"] = "The page was open for longer than one minute";
                return Page();
            }

            var employee = await _context.Employees.FirstOrDefaultAsync(m => m.EmployeeId== EmployeeAttendance.EmployeeId);
            if (employee == null)
            {
                ModelState.AddModelError(string.Empty, "Employee ID not found. Contact support.");
                return Page();
            }

            if (!ModelState.IsValid)
            {
                TempData["error"] = "Invalid request";
                return Page();
            }

            if (EmployeeAttendance.CheckIn.Hour < 7)
            {   // Checking in before 7 AM is not allowed
                //ModelState.AddModelError(string.Empty, "Check in starts at 7 AM.");
                TempData["error"] = "Checking in starts at 7AM";
                return Page();
            }

            if (EmployeeAttendance.CheckIn.Hour > 8
                || (EmployeeAttendance.CheckIn.Hour == 8 && EmployeeAttendance.CheckIn.Minute > 29))
            {   // Checking in after 8:30 AM should be flagged with LateCheckIn
                EmployeeAttendance.LateCheckIn = true;
                TempData["warning"] = "Late check in recorded";
            }

            _context.EmpAttendances.Add(EmployeeAttendance);
            await _context.SaveChangesAsync();
            TempData["success"] = "Checked in successfully";

            return RedirectToPage("./Index");
        }
    }
}
