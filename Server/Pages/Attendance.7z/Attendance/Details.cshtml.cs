﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Models;

namespace Server.Pages.Attendance
{
    public class DetailsModel : PageModel
    {
        private readonly Server.Data.ApplicationDBContext _context;

        public DetailsModel(Server.Data.ApplicationDBContext context)
        {
            _context = context;
        }

      public Model.EmployeeAttendance EmployeeAttendance { get; set; }

        public async Task<IActionResult> OnGetAsync(DateTime? id)
        {
            if (id == null || _context.EmpAttendances == null)
            {
                return NotFound();
            }

            var employeeattendance = await _context.EmpAttendances.FirstOrDefaultAsync(m => m.CheckIn == id);
            if (employeeattendance == null)
            {
                return NotFound();
            }
            else 
            {
                EmployeeAttendance = employeeattendance;
            }
            return Page();
        }
    }
}
