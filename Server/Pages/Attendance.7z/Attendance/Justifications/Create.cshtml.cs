﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Server.Data;
using Server.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace Server.Pages.Attendance.Justifications
{
    public class CreateModel : PageModel
    {
        private readonly Server.Data.ApplicationDBContext _context;

        public CreateModel(Server.Data.ApplicationDBContext context)
        {
            _context = context;
        }


        public async Task<IActionResult> OnGetAsync(int empId, DateTime checkInTime)
        //public IActionResult OnGet()
        {
            EmployeeAttendance = await _context.EmpAttendances.FindAsync(empId, checkInTime);
            if (EmployeeAttendance == null)
            {
                return NotFound();
            }

            return Page();
        }

        [BindProperty]
        public Justification Justification { get; set; }
        [BindProperty]
        public EmployeeAttendance EmployeeAttendance { get; set; }
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                TempData["error"] = "Invalid request";
                return Page();
            }

            if (EmployeeAttendance.EmployeeId <= 0)
            {
                return NotFound();
            }
            Justification.EmployeeId = EmployeeAttendance.EmployeeId;
            Justification.CheckIn = EmployeeAttendance.CheckIn;
            Justification.DateCreated = DateTime.Now;

            _context.Justifications.Add(Justification);
            await _context.SaveChangesAsync();
            TempData["success"] = "Justification sent successfully";

            return RedirectToPage("./Index");
        }
    }
}
