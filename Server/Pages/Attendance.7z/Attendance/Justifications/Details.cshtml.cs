﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Models;

namespace Server.Pages.Attendance.Justifications
{
    public class DetailsModel : PageModel
    {
        private readonly Server.Data.ApplicationDBContext _context;

        public DetailsModel(Server.Data.ApplicationDBContext context)
        {
            _context = context;
        }

      public Justification Justification { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Justifications == null)
            {
                return NotFound();
            }

            var justification = await _context.Justifications.FirstOrDefaultAsync(m => m.JustificationId == id);
            if (justification == null)
            {
                return NotFound();
            }
            else 
            {
                Justification = justification;
            }
            return Page();
        }
    }
}
