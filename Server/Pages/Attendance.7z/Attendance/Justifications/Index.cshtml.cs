﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Models;

namespace Server.Pages.Attendance.Justifications
{
    public class IndexModel : PageModel
    {
        private readonly Server.Data.ApplicationDBContext _context;

        public IndexModel(Server.Data.ApplicationDBContext context)
        {
            _context = context;
        }

        public IList<Justification> Justification { get;set; } = default!;
        //public IList<Employee> Employee { get; set; }

        public async Task OnGetAsync()
        {
            if (_context.Justifications != null)
            {
                Justification = await _context.Justifications.ToListAsync();
            }

            //if (_context.Employees != null)
            //{
            //    Employee = await _context.Employees.ToListAsync();
            //}
        }
    }
}
